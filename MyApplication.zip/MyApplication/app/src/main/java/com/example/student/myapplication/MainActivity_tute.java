package com.example.student.myapplication;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity_tute extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_tute);
    }

    public void changeFragment(View view){

        Fragment fragment;

            if(view == findViewById(R.id.btnFragment1)){

                fragment = new Fragment();

                FragmentManager fm =getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragmentDefult,fragment);
                ft.commit();
            }

            if (view == findViewById(R.id.btnFragment2)){

                fragment = new BlankFragment2();
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragmentDefult,fragment);
                ft.commit();
            }
    }
}
